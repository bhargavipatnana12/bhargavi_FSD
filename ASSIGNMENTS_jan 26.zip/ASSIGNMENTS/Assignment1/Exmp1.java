package ex1;

import java.util.Scanner;

public class Exmp1 {

	public static void main(String[] args) {
		 String name;
		 int year;
        Scanner sc= new  Scanner(System.in);
         name=sc.nextLine();
         year=sc.nextInt();
         System.out.println("My name is "+name+" and I'll graduate in "+year);
        
		
	}

}