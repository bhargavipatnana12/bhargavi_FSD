package com.cts.training.lib;

public class Array {
     public void average(int arr[]) {
    	 {
    		float avg=0;
    		int sum=0,len,count=0;
    		 len=arr.length;
    		 for(int i=0;i<=len;i++) {
    			    if (arr[i]%5==0)
    			    {
    			    	sum=sum+arr[i];
    			    	count++;
    			    	 avg=sum/count;
    			}
    		 }
    	 }
    	 
     }
     
     
     public void minposition (int n) {
    	  int min=arr[];
    	  Object ;
	
      	 
     }
}