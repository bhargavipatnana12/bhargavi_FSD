package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*Id
Buyer_id
Seller_id
Transaction_id
Item_id
Number_of_items
Date_time
remarks*/
@Entity
@Table(name="purchase_history")

public class Purchase_history {
	@Id
	private int id;
	@Column(name="buyer_id")
	private int buyer_id;
	@Column(name="seller_id")
	private int seller_id;
	@Column(name="transaction_id")
	private int transaction_id;
	@Column(name="item_id")
	private int item_id;
	@Column(name="Number_of_items")
	private int Number_of_items;
	@Column(name="Date_time")
	private String Date_time;
	@Column(name="remarks")
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBuyer_id() {
		return buyer_id;
	}
	public void setBuyer_id(int buyer_id) {
		this.buyer_id = buyer_id;
	}
	public int getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public int getNumber_of_items() {
		return Number_of_items;
	}
	public void setNumber_of_items(int number_of_items) {
		Number_of_items = number_of_items;
	}
	public String getDate_time() {
		return Date_time;
	}
	public void setDate_time(String date_time) {
		Date_time = date_time;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Purchase_history() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Purchase_history(int id, int buyer_id, int seller_id, int transaction_id, int item_id, int number_of_items,
			String date_time, String remarks) {
		super();
		this.id = id;
		this.buyer_id = buyer_id;
		this.seller_id = seller_id;
		this.transaction_id = transaction_id;
		this.item_id = item_id;
		Number_of_items = number_of_items;
		Date_time = date_time;
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Purchase_history [id=" + id + ", buyer_id=" + buyer_id + ", seller_id=" + seller_id
				+ ", transaction_id=" + transaction_id + ", item_id=" + item_id + ", Number_of_items=" + Number_of_items
				+ ", Date_time=" + Date_time + ", remarks=" + remarks + "]";
	}
	
}














